
const WIDTH = 640;
const HEIGHT = 640;
const SPRITE_SIZE = 32;
const COLS = WIDTH/SPRITE_SIZE;
const ROWS = HEIGHT/SPRITE_SIZE;
const MAX_BODY = (WIDTH/SPRITE_SIZE)*(HEIGHT/SPRITE_SIZE)-1;

function game() {
    this.FPS = 1000/60;
    this.MPS = 500;
    this.MAX_MPS = 100;
    this.MAX_PORTALS = 3;
    this.canvas = document.getElementById('canvas');
    this.canvas.width = WIDTH;
    this.canvas.height = HEIGHT;
    this.ctx = this.canvas.getContext('2d');
    this.scoreCanvas = document.getElementById('scoreCanvas');
    this.scoreCanvas.width = WIDTH;
    this.scoreCanvas.height = 50;
    this.scoreCtx = this.scoreCanvas.getContext('2d');
    this.score = 0;
    this.assetsloaded = 0;
    this.KEYS = [
        87, 65, 83, 68,
        37, 38, 39, 40
    ]
    this.init = () => {
        this.loadAssets();
    }
    this.startGame = () => {
        this.portals = [];
        const p = {
            position: {x: Math.floor(Math.random() * COLS), y: Math.floor(Math.random() * ROWS)},
            sprite: this.portalRef,
            render: function(ctx){
                ctx.drawImage(this.sprite, 0, 0, 32, 32, this.position.x*32, this.position.y*32, 32, 32);
            }
        }
        this.portals.push(p);
        this.snake = new Snake(this.headRef, this.bodyRef, this.ctx, this);
        this.started = false;
        this.canvas.addEventListener('click', this.awaitClickStart);
        this.interval = setInterval(this.renderUpdate, this.FPS);
    }
    this.awaitClickStart = () => {
        window.addEventListener('keydown', this.handleKeyEvents);
        this.music = new Audio('./sfx/creep.m4a');
        this.music.loop = true;
        this.music.volume = 0.25;
        this.music.play();
        this.moveInterval = setInterval(this.moveUpdate, this.MPS);
        this.started = true;
        this.canvas.removeEventListener('click', this.awaitClickStart);
    }
    this.movePortal = (portal) => {
        let placed = false;
        while(!placed){
            let newPos = {x: Math.floor(Math.random() * WIDTH/SPRITE_SIZE), y: Math.floor(Math.random() * HEIGHT/SPRITE_SIZE)};
            if(!this.hasObjectAtPosition(newPos)) {
                portal.position = newPos;
                placed = true;
            }
        }
    }
    this.hasObjectAtPosition = (pos) => {
        if(this.snake.head.position.x === pos.x && this.snake.head.position.y === pos.y) return true;
        let hasObject = false;
        this.snake.body.forEach(part => {
            if(part.position.x === pos.x && part.position.y === pos.y) {
                hasObject = true;
                return;
            }
        })
        return hasObject;
    }
    this.showScore = () => {
        this.scoreCtx.clearRect(0, 0, this.scoreCanvas.width, this.scoreCanvas.height);
        this.scoreCtx.font = "30px Arial";
        this.scoreCtx.fillStyle = 'black';
        this.scoreCtx.fillText(`${this.gameOver ? 'Final Score: ' : 'Current Score: '}${this.score}`, 10, this.scoreCanvas.height/2+10);
    }
    this.showGameOver = () => {
        this.ctx.fillStyle = 'black';
        this.ctx.fillRect(0, 0, WIDTH, HEIGHT);
        this.ctx.font = "30px Arial";
        this.ctx.fillStyle = 'white';
        this.ctx.textAlign = 'center';
        this.ctx.fillText("GameOver", this.canvas.width/2, this.canvas.height/2);
    }
    this.showSplashScreen = () => {
        this.ctx.fillStyle = 'black';
        this.ctx.fillRect(0, 0, WIDTH, HEIGHT);
        this.ctx.font = "30px Arial";
        this.ctx.fillStyle = 'white';
        this.ctx.textAlign = 'center';
        this.ctx.fillText("click here to start", this.canvas.width/2, this.canvas.height/2);
    }
    this.createPortal = () => {
        const p = {
            sprite: this.portalRef,
            render: function(ctx){
                ctx.drawImage(this.sprite, 0, 0, 32, 32, this.position.x*32, this.position.y*32, 32, 32);
            }
        }
        this.movePortal(p);
        this.portals.push(p);
    }
    this.renderUpdate = () => {
        this.clearCanvas();
        if(!this.started) {
            this.showSplashScreen();
        }
        if(this.started && !this.gameOver){
            this.snake.render();
            this.portals.forEach(portal => portal.render(this.ctx));
        } else if(this.started && this.gameOver) {
            this.showGameOver();
        }
        if((new Date().getTime() - this?.startTime)/1000 > 30 ){
            if(this.portals.length !== this.MAX_PORTALS){
                this.createPortal();
            }
            if(this.MPS > this.MAX_MPS){
                this.startTime = new Date().getTime();
                clearInterval(this.moveInterval);
                this.MPS-=50;
                this.moveInterval = setInterval(this.moveUpdate, this.MPS);
            }
        }
        if(this.snake.body.length === MAX_BODY){
            console.log("wow, you actually won...");
            this.endGame();
        }
        this.showScore();
    }
    this.moveUpdate = () => {
        if(this.snake.head.direction !== '') this.snake.move();
    }
    this.imageOnLoad = () => {
        this.assetsloaded+=1;
        if(this.assetsloaded === 3) this.startGame();
    }
    this.loadAssets = () => {
        const head = new Image();
        head.src = './sprites/head.png';
        head.onload = this.imageOnLoad;
        this.headRef = head;

        const body = new Image();
        body.src = './sprites/body.png';
        body.onload = this.imageOnLoad;
        this.bodyRef = body;

        const portal = new Image();
        portal.src = './sprites/portal.png';
        portal.onload = this.imageOnLoad;
        this.portalRef = portal;
    }
    this.clearCanvas = () => {
        this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
    this.isPortal = (head) => {
        this.portals.forEach((portal) => {
            if(portal.position.x === head.position.x && portal.position.y === head.position.y) {
                this.snake.addNewPart();
                this.score+=10;
                this.movePortal(portal);
            }
        })
    }
    this.handleKeyEvents = (e) => {
        const key = e.keyCode;
        if(this.KEYS.includes(key)){
            if(this.snake.head.direction === '') this.startTime = new Date().getTime();
            if(key === 87 || key === 38){
                const desiredPos = { x: this.snake.head.position.x, y: this.snake.head.position.y-1 };
                if(this.snake.body[0]?.position.x !== desiredPos.x && this.snake.body[0]?.position.y !== desiredPos.y){
                    this.snake.setDirection('up');
                }
            } else if(key === 65 || key === 37){
                const desiredPos = { x: this.snake.head.position.x-1, y: this.snake.head.position.y };
                if(this.snake.body[0]?.position.x !== desiredPos.x && this.snake.body[0]?.position.y !== desiredPos.y){
                    this.snake.setDirection('left');
                }
                
            } else if(key === 83 || key === 40){
                const desiredPos = { x: this.snake.head.position.x, y: this.snake.head.position.y+1 };
                if(this.snake.body[0]?.position.x !== desiredPos.x && this.snake.body[0]?.position.y !== desiredPos.y){
                    this.snake.setDirection('down');
                }
            } else {
                const desiredPos = { x: this.snake.head.position.x+1, y: this.snake.head.position.y };
                if(this.snake.body[0]?.position.x !== desiredPos.x && this.snake.body[0]?.position.y !== desiredPos.y){
                    this.snake.setDirection('right');
                }
            }
        }
    }
    this.endGame = () => {
        clearInterval(this.moveInterval);
        this.gameOver = true;
        this.music.pause();
    }
    
}
class Snake {
    head = {};
    body = [];
    constructor(headRef, bodyRef, ctx, gameRef){
        if(!headRef || !bodyRef || !ctx || !gameRef) {
            throw new Error("references are missing");
        }
        this.headRef = headRef;
        this.bodyRef = bodyRef;
        this.ctx = ctx;
        this.gameRef = gameRef;
        this.init();
    }
    init = function() {
        this.partCreator = new PartCreator();
        this.head = this.partCreator.createPart(this.headRef, { x: 10, y: 10 }, '');
    }
    setDirection = function(direction){
        this.head.direction = direction;
    }
    addNewPart = function(){
        if(this.body.length === 0){
            let pos, dir;
            switch(this.head.direction){
                case 'up':
                    pos = { x: this.head.position.x, y: this.head.position.y+2 };
                    dir = 'up';
                    break;
                case 'left':
                    pos = { x: this.head.position.x+2, y: this.head.position.y };
                    dir = 'left';
                    break;
                case 'down':
                    pos = { x: this.head.position.x, y: this.head.position.y-2 };
                    dir = 'down';
                    break;
                case 'right':
                    pos = { x: this.head.position.x-2, y: this.head.position.y };
                    dir = 'right';
                    break;
            }
            const part = this.partCreator.createPart(this.bodyRef, pos, dir);
            this.body.push(part);
        } else {
            let tail = this.body[this.body.length-1];
            let pos, dir;
            switch(tail.direction){
                case 'up':
                    pos = { x: tail.position.x , y: tail.position.y+1 };
                    dir = 'up';
                    break;
                case 'left':
                    pos = { x: tail.position.x+1, y: tail.position.y };
                    dir = 'left';
                    break;
                case 'down':
                    pos = { x: tail.position.x , y: tail.position.y-1 };
                    dir = 'down';
                    break;
                case 'right':
                    pos = { x: tail.position.x-1 , y: tail.position.y };
                    dir = 'right';
                    break;
            }
            const part = this.partCreator.createPart(this.bodyRef, pos, dir);
            this.body.push(part);
        }
    }
    willCollide = function(){
        let nextPos;
        switch(this.head.direction){
            case 'up':
                nextPos = { x: this.head.position.x, y: this.head.position.y-1 };
                break;
            case 'left':
                nextPos = { x: this.head.position.x-1, y: this.head.position.y };
                break;
            case 'down':
                nextPos = { x: this.head.position.x, y: this.head.position.y+1 };
                break;
            case 'right':
                nextPos = { x: this.head.position.x+1, y: this.head.position.y };
                break;
        }
        if(nextPos.x < 0 || nextPos.x >= (WIDTH/SPRITE_SIZE) || nextPos.y < 0 || nextPos.y >= (HEIGHT/SPRITE_SIZE)) return true;
        let collided = false;
        this.body.forEach(part => {
            if(part.position.x === nextPos.x && part.position.y === nextPos.y) {
                collided = true;
                return;
            }
        })
        return collided;
    }
    move = function(){
        if(this.willCollide()){
            this.gameRef.endGame();
            return;
        }
        this.head.move();
        this.gameRef.isPortal(this.head);
        let prevDirection = this.head.direction;
        this.body.forEach(part => {
            part.move();
            [part.direction, prevDirection] = [prevDirection, part.direction];
        })
    }
    render = function(){
        this.head.render(this.ctx);
        this.body.forEach(part => part.render(this.ctx));
    }
}
class PartCreator {
    createPart = function(sprite, position, direction){
        const part = {};
        part.sprite = sprite;
        part.position = position;
        part.direction = direction;
        part.moveSpeed = 1;
        part.render = function(ctx){
            ctx.drawImage(this.sprite, 0, 0, 32, 32, this.position.x*32, this.position.y*32, 32, 32);
        }
        part.move = function(){
            switch(this.direction){
                case 'left':
                    this.position.x-=this.moveSpeed;
                    break;
                case 'right':
                    this.position.x+=this.moveSpeed;
                    break;
                case 'up':
                    this.position.y-=this.moveSpeed;
                    break;
                case 'down':
                    this.position.y+=this.moveSpeed;
                    break;
            }
        }
        return part;
    }
}
const Game = new game();
Game.init();
