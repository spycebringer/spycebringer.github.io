This is a step by step for creating a github page (assuming you already have an account).

1. navigate to https://github.com/ and sign in if you haven't already.
2. click the green "new" button on the left side of the page, next to where it says "repositories".
3. !important! for the repository name it needs to be your username.github.io. 
    example: my github username is tester01. my repository name is tester01.github.io.
4. under 'Quick Settup' near the top, there will be a link that says 'upload an existing file', 
    click that and select the root folder that i sent(ghost.io).
5. navigate to your repository once it uploads and click on setting near the top.
6. for the source, set it to the master branch and leave it at the root folder.
7. click save and in a few moments it should be live. 
8. navigate to YOURUSERNAME.github.io